export default class NotFoundPage {
    async render() {
        return `
      <section class="container">
        <h1 class="section-title">Halaman tidak ditemukan!</h1>
      </section>
    `;
    }
}